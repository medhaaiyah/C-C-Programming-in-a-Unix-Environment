/*Filename: header.h
 *Date: 1.26.2020
 *Author: Medha Aiyah
 *Email: mva170001@utdallas.edu
 *Course: CS 3377.501 Spring 2020
 *Copyright 2020, All Rights Reserved
 *
 *Description: This is the header file and it will call the procedure function.
*/

#include <iostream>

//It is calling the procedure function

int procedure();
